#ifndef ASSIGNMENT_IMAGE_ROTATION_ROTATION_H
#define ASSIGNMENT_IMAGE_ROTATION_ROTATION_H
#include "bmp.h"

struct image rotate(struct image image);
#endif //ASSIGNMENT_IMAGE_ROTATION_ROTATION_H
