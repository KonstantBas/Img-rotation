#ifndef _UTIL_H_
#define _UTIL_H_

_Noreturn void err( const char* msg, ... );

#endif
